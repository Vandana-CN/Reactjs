import './App.css';
import {BrowserRouter as Router,Routes,Route,Link} from "react-router-dom";
import Home from './components/Home';
import About from './components/About';
import {Login} from './components/Login';
import Profile from './components/Profile';
import Protected from './components/Protected';

function App() {

  return(

    <Router>

      <nv>

        <Link to="/">Home</Link>

        <Link to="/AboutUs">About us</Link>

        <Link to="/Login">Login</Link>

        <Link to="/Profile">Profile</Link>

      </nv>

      <Routes>

        <Route path="/" element={<Protected Component={Home}/>}/>

        <Route path="/AboutUs" element={<Protected Component={About}/>}/>

        <Route path="/Profile" element={<Protected Component={Profile}/>}/>

        <Route path="/Login" element={<Login/>}/>    


      </Routes>

    </Router>

  );

}



export default App;


